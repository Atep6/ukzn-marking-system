# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - heading "Welcome to the Dashboard" [level=1] [ref=e2]
  - button "Sync" [ref=e3]
  - generic [ref=e4]: Online
```